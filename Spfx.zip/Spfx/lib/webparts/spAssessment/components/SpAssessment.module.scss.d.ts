declare const styles: {
    spAssessment: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=SpAssessment.module.scss.d.ts.map