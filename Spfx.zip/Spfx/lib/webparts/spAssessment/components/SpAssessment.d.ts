import * as React from 'react';
import type { ISpAssessmentProps } from './ISpAssessmentProps';
export default class SpAssessment extends React.Component<ISpAssessmentProps> {
    render(): React.ReactElement<ISpAssessmentProps>;
}
//# sourceMappingURL=SpAssessment.d.ts.map