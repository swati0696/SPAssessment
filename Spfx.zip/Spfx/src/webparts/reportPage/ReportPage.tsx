import * as React from 'react';
import { useEffect, useState } from 'react';
import { Chart } from 'chart.js';
import { sp } from "@pnp/sp/presets/all";
import { Dropdown, IDropdownOption, Stack, Text } from '@fluentui/react';
import '@pnp/sp/lists';
import '@pnp/sp/items';

const ReportPage: React.FC = () => {
  const [reportData, setReportData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [categories, setCategories] = useState<IDropdownOption[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(undefined);

  useEffect(() => {
    // Initialize PnPJS
    sp.setup({ spfxContext: this.context });

    // Fetch data from SharePoint list
    const fetchData = async () => {
      const items: any[] = await sp.web.lists.getByTitle("ReportsData").items.get();
      setReportData(items);
      setFilteredData(items);
      
      // Extract categories for filtering
      const uniqueCategories = [...new Set(items.map(item => item.Category))];
      setCategories(uniqueCategories.map(cat => ({ key: cat, text: cat })));
    };

    fetchData();
  }, []);

  useEffect(() => {
    // Render chart whenever filtered data changes
    if (filteredData.length > 0) {
      renderChart(filteredData);
    }
  }, [filteredData]);

  const renderChart = (data) => {
    const ctx = document.getElementById("reportChart") as HTMLCanvasElement;
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: data.map(item => item.Title),
        datasets: [{
          label: 'Value',
          data: data.map(item => item.Value),
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  };

  const onCategoryChange = (event, option) => {
    setSelectedCategory(option.key as string);
    const filtered = reportData.filter(item => item.Category === option.key);
    setFilteredData(filtered);
  };

  return (
    <div style={{ padding: '20px' }}>
      <Text variant="xxLarge">Report Page</Text>
      <Text variant="medium">View and analyze your reports below.</Text>

      {/* Filter dropdown */}
      <Dropdown
        label="Filter by Category"
        options={categories}
        selectedKey={selectedCategory}
        onChange={onCategoryChange}
        placeholder="Select a category"
      />

      {/* Chart */}
      <canvas id="reportChart" width="400" height="200"></canvas>
    </div>
  );
};

export default ReportPage;
