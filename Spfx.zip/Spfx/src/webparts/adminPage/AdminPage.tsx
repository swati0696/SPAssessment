import * as React, { useEffect, useState } from 'react';
import { sp } from "@pnp/sp/presets/all";
import { TextField, DatePicker, Dropdown, PrimaryButton, Stack, MessageBar, MessageBarType } from '@fluentui/react';
import '@pnp/sp/lists';
import '@pnp/sp/items';

const AdminPage: React.FC = () => {
  const [trainingData, setTrainingData] = useState([]);
  const [formValues, setFormValues] = useState({ courseName: '', description: '', startDate: null, endDate: null, assignedUsers: [] });
  const [selectedItem, setSelectedItem] = useState(null);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    // Initialize PnPJS
    sp.setup({ spfxContext: this.context });

    // Load data from SharePoint list
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const items: any[] = await sp.web.lists.getByTitle("TrainingData").items.get();
      setTrainingData(items);
    } catch (error) {
      console.error("Error loading data", error);
    }
  };

  const handleChange = (e, field) => {
    setFormValues({ ...formValues, [field]: e.target ? e.target.value : e });
  };

  const validateForm = () => {
    const { courseName, description, startDate, endDate } = formValues;
    if (!courseName || !description || !startDate || !endDate) {
      setMessage({ type: MessageBarType.error, text: "All fields are required." });
      return false;
    }
    if (new Date(startDate) > new Date(endDate)) {
      setMessage({ type: MessageBarType.error, text: "End Date should be after Start Date." });
      return false;
    }
    setMessage(null);
    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    const payload = {
      Title: formValues.courseName,
      Description: formValues.description,
      StartDate: formValues.startDate,
      EndDate: formValues.endDate,
      AssignedUsers: { results: formValues.assignedUsers.map(user => user.id) }
    };

    try {
      if (selectedItem) {
        await sp.web.lists.getByTitle("TrainingData").items.getById(selectedItem.Id).update(payload);
      } else {
        await sp.web.lists.getByTitle("TrainingData").items.add(payload);
      }
      loadData();
      setFormValues({ courseName: '', description: '', startDate: null, endDate: null, assignedUsers: [] });
      setSelectedItem(null);
      setMessage({ type: MessageBarType.success, text: "Data saved successfully." });
    } catch (error) {
      setMessage({ type: MessageBarType.error, text: "Error saving data." });
      console.error("Error saving data", error);
    }
  };

  const handleDelete = async (itemId) => {
    try {
      await sp.web.lists.getByTitle("TrainingData").items.getById(itemId).delete();
      loadData();
      setMessage({ type: MessageBarType.success, text: "Data deleted successfully." });
    } catch (error) {
      setMessage({ type: MessageBarType.error, text: "Error deleting data." });
      console.error("Error deleting data", error);
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Admin Page - Manage Training Data</h2>

      {message && (
        <MessageBar messageBarType={message.type} isMultiline={false}>
          {message.text}
        </MessageBar>
      )}

      {/* Form */}
      <Stack tokens={{ childrenGap: 10 }} style={{ maxWidth: '500px' }}>
        <TextField label="Course Name" required value={formValues.courseName} onChange={(e) => handleChange(e, 'courseName')} />
        <TextField label="Description" required multiline value={formValues.description} onChange={(e) => handleChange(e, 'description')} />
        <DatePicker label="Start Date" required value={formValues.startDate} onSelectDate={(date) => handleChange(date, 'startDate')} />
        <DatePicker label="End Date" required value={formValues.endDate} onSelectDate={(date) => handleChange(date, 'endDate')} />
        <Dropdown label="Assigned Users" multiSelect placeholder="Select users" options={/* Fetch users here */} onChange={(e, option) => handleChange(e, 'assignedUsers')} />
        <PrimaryButton text={selectedItem ? "Update" : "Create"} onClick={handleSubmit} />
      </Stack>

      {/* Data Table */}
      <h3>Training Data List</h3>
      <table>
        <thead>
          <tr>
            <th>Course Name</th>
            <th>Description</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {trainingData.map(item => (
            <tr key={item.Id}>
              <td>{item.Title}</td>
              <td>{item.Description}</td>
              <td>{new Date(item.StartDate).toLocaleDateString()}</td>
              <td>{new Date(item.EndDate).toLocaleDateString()}</td>
              <td>
                <button onClick={() => { setFormValues(item); setSelectedItem(item); }}>Edit</button>
                <button onClick={() => handleDelete(item.Id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminPage;
