import * as React from 'react';
import { PrimaryButton, Stack, Text } from '@fluentui/react';
import logo from '../assets/Assests/LOGO.png';
import heroImage from '../assets/Assests/BANNER IMAGE.jpg';
import cartIcon from '../assets/Assests/cart_normal.png';
import bellIcon from '../assets/Assests/Noti_Normal.png';
import profileImage from '../assets/Assests/profile.png';
import courseImage from '../assets/Assests/Group 16129.jpg';
import checkmarkIcon from '../assets/Assests/Group 16130.png';  // Checkmark icon
import searchIcon from '../assets/Assests/search.png'; // Import the search icon


const HomePage: React.FC = () => {
  return (
    <div className="page-container">

      {/* Top Navigation Bar */}
      <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 20px', backgroundColor: '#ffffff', boxShadow: '0px 1px 5px rgba(0, 0, 0, 0.1)' }}>
        <img src={logo} alt="Logo" style={{ width: '120px' }} />
        {/* <TextField placeholder="Search" style={{ width: '300px' }} /> */}
        {/* Search Box with Icon */}
        <div style={{ position: 'relative', width: '300px' }}>
          <input 
            type="text" 
            placeholder="Search" 
            style={{ 
              width: '100%', 
              padding: '10px 40px 10px 15px', 
              borderRadius: '20px', 
              border: '1px solid #ccc', 
              outline: 'none' 
            }}
          />
          <img 
            src={searchIcon} 
            alt="Search Icon" 
            style={{ 
              position: 'absolute', 
              right: '10px', 
              top: '50%', 
              transform: 'translateY(-50%)', 
              width: '20px', 
              height: '20px' 
            }}
          />
        </div>

        <Stack horizontal tokens={{ childrenGap: 10 }} verticalAlign="center">
          <PrimaryButton text="Raise a Ticket" style={{ backgroundColor: '#0078d4', color: '#fff' }} />
          <img src={cartIcon} alt="Cart" style={{ width: '30px', height: '30px', cursor: 'pointer' }} />
          <img src={bellIcon} alt="Notifications" style={{ width: '30px', height: '30px', cursor: 'pointer' }} />
          <img src={profileImage} alt="Profile" style={{ width: '30px', height: '30px', borderRadius: '50%', cursor: 'pointer' }} />
          <Stack horizontal verticalAlign="center" tokens={{ childrenGap: 5 }}>
            <Text variant="medium" style={{ cursor: 'pointer' }}>Home</Text>
            <Text variant="medium" style={{ cursor: 'pointer' }}>Overview</Text>
            <Text variant="medium" style={{ cursor: 'pointer' }}>Dashboard</Text>
            <Text variant="medium" style={{ cursor: 'pointer' }}>Administration</Text>
          </Stack>
        </Stack>
      </header>

      {/* Hero Section with Satisfaction Label */}
      <section style={{ backgroundImage: `url(${heroImage})`, backgroundSize: 'cover', padding: '60px 20px', color: '#fff', textAlign: 'left', display: 'flex', alignItems: 'center', justifyContent: 'center', height: '400px' }}>
        <div style={{ maxWidth: '600px', backgroundColor: 'rgba(255, 255, 255, 0.8)', padding: '20px', borderRadius: '8px' }}>
          <Text variant="small" style={{ backgroundColor: '#0078d4', color: '#ffffff', padding: '5px 10px', borderRadius: '5px', fontWeight: 'bold', marginBottom: '10px', display: 'inline-block' }}>
            100% Satisfaction Guarantee
          </Text>
          <Text variant="xxLarge" style={{ fontWeight: 'bold', color: '#333333' }}>Start Your Learning Journey Today</Text>
          <Text variant="large" style={{ marginTop: '10px', color: '#333333' }}>
            Growth with our comprehensive online learning platform. Whether you're looking to advance your career, explore new interests.
          </Text>
          <PrimaryButton text="Discover Programs" href="/sitepages/ReportPage.aspx" style={{ marginTop: '20px', backgroundColor: '#0078d4', color: '#fff' }} />
        </div>
      </section>

      {/* Discover Our Online Learning Programs Section */}
      <section style={{ padding: '60px 20px', display: 'flex', justifyContent: 'center', alignItems: 'center', backgroundColor: '#f9f9f9' }}>
        <div style={{ display: 'flex', alignItems: 'center', maxWidth: '1000px', gap: '30px' }}>
          <Stack horizontal tokens={{ childrenGap: 15 }} style={{ flex: '1', justifyContent: 'center' }}>
            <img src={require('../assets/Assests/Group 16128.png')} alt="Feature 1" style={{ width: '200px', borderRadius: '10px' }} />
            {/* <img src={require('../assets/Assests/Group 16129.png')} alt="Feature 2" style={{ width: '200px', borderRadius: '10px' }} /> */}
          </Stack>
          <div style={{ flex: '1' }}>
            <Text variant="small" style={{ color: '#0078d4', fontWeight: 'bold', marginBottom: '10px', display: 'inline-block' }}>Get To Know About Us</Text>
            <Text variant="xxLarge" style={{ fontWeight: 'bold', marginBottom: '15px', color: '#1d1d1d' }}>Discover Our Online Learning Programs</Text>
            <Text variant="large" style={{ color: '#555', marginBottom: '20px' }}>
              Dive into a rich array of courses meticulously crafted to cater to your educational aspirations and professional growth. Explore diverse subjects, from business.
            </Text>
            <Stack tokens={{ childrenGap: 10 }} style={{ marginBottom: '20px' }}>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <img src={checkmarkIcon} alt="Checkmark" style={{ width: '20px', height: '20px', marginRight: '8px' }} />
                <Text variant="mediumPlus">Seamless Scheduling</Text>
              </div>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <img src={checkmarkIcon} alt="Checkmark" style={{ width: '20px', height: '20px', marginRight: '8px' }} />
                <Text variant="mediumPlus">Service Guarantee</Text>
              </div>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <img src={checkmarkIcon} alt="Checkmark" style={{ width: '20px', height: '20px', marginRight: '8px' }} />
                <Text variant="mediumPlus">Integrated Collaboration</Text>
              </div>
            </Stack>
            <PrimaryButton text="Discover More" href="/sitepages/LearningPrograms.aspx" style={{ backgroundColor: '#0078d4', color: '#fff' }} />
          </div>
        </div>
      </section>

      {/* Our Latest News & Blog Section */}
      <section style={{ padding: '60px 20px', backgroundColor: '#f3f4f6', textAlign: 'center' }}>
        <Text variant="small" style={{ color: '#0078d4', fontWeight: 'bold', display: 'inline-block', marginBottom: '10px' }}>Get To Know About Us</Text>
        <Text variant="xxLarge" style={{ fontWeight: 'bold', color: '#1d1d1d' }}>Our Latest News & Blog</Text>
        <Text variant="large" style={{ color: '#555', marginTop: '10px', marginBottom: '30px' }}>
          Explore insightful articles, industry trends, and exciting updates curated just for you.
        </Text>
        <Stack horizontal horizontalAlign="center" wrap tokens={{ childrenGap: 20 }} style={{ marginTop: '30px' }}>
          <div style={{ width: '300px', backgroundColor: '#ffffff', padding: '20px', borderRadius: '8px', boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.1)' }}>
            <img src={require('../assets/Assests/01.jpg')} alt="Blog 1" style={{ width: '100%', borderRadius: '8px' }} />
            <Text variant="small" style={{ backgroundColor: '#eef2ff', color: '#1d1d1d', padding: '5px 10px', borderRadius: '5px', fontWeight: 'bold', marginTop: '10px', display: 'inline-block' }}>Business</Text>
            <Text variant="large" style={{ fontWeight: 'bold', marginTop: '10px' }}>Top 10 Skills to Thrive in the Digital Age</Text>
            <Text variant="small" style={{ color: '#555', marginTop: '5px' }}>By John - August 25, 2023</Text>
          </div>
          <div style={{ width: '300px', backgroundColor: '#ffffff', padding: '20px', borderRadius: '8px', boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.1)' }}>
            <img src={require('../assets/Assests/02.jpg')} alt="Blog 1" style={{ width: '100%', borderRadius: '8px' }} />
            <Text variant="small" style={{ backgroundColor: '#eef2ff', color: '#1d1d1d', padding: '5px 10px', borderRadius: '5px', fontWeight: 'bold', marginTop: '10px', display: 'inline-block' }}>Finance</Text>
            <Text variant="large" style={{ fontWeight: 'bold', marginTop: '10px' }}>Navigating the Future of Remote learning</Text>
            <Text variant="small" style={{ color: '#555', marginTop: '5px' }}>By Natasha - June 12, 2023</Text>
          </div>
          <div style={{ width: '300px', backgroundColor: '#ffffff', padding: '20px', borderRadius: '8px', boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.1)' }}>
            <img src={require('../assets/Assests/03.jpg')} alt="Blog 1" style={{ width: '100%', borderRadius: '8px' }} />
            <Text variant="small" style={{ backgroundColor: '#eef2ff', color: '#1d1d1d', padding: '5px 10px', borderRadius: '5px', fontWeight: 'bold', marginTop: '10px', display: 'inline-block' }}>Data Science</Text>
            <Text variant="large" style={{ fontWeight: 'bold', marginTop: '10px' }}>What leonardo teach us about web Design</Text>
            <Text variant="small" style={{ color: '#555', marginTop: '5px' }}>By William - July 29, 2023</Text>
          </div>
        </Stack>
      </section>

      {/* Find Your Path with Our Online Courses Section */}
      <section style={{ padding: '60px 20px', display: 'flex', justifyContent: 'center', alignItems: 'center', backgroundColor: '#f9f9f9' }}>
        <div style={{ display: 'flex', alignItems: 'center', maxWidth: '1000px', gap: '30px' }}>
          <div style={{ flex: '1' }}>
            <Text variant="small" style={{ color: '#0078d4', fontWeight: 'bold', marginBottom: '10px', display: 'inline-block' }}>Get To Know About Us</Text>
            <Text variant="xxLarge" style={{ fontWeight: 'bold', marginBottom: '15px', color: '#1d1d1d' }}>Find Your Path with Our Online Courses</Text>
            <Text variant="large" style={{ color: '#555', marginBottom: '20px' }}>
              Embark on a personalized journey of growth and discovery with our online courses. Whether you're charting a new career path or expanding your skills.
            </Text>
            <Stack tokens={{ childrenGap: 10 }} style={{ marginBottom: '20px' }}>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <img src={checkmarkIcon} alt="Checkmark" style={{ width: '20px', height: '20px', marginRight: '8px' }} />
                <Text variant="mediumPlus">Personalized Learning Paths</Text>
              </div>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <img src={checkmarkIcon} alt="Checkmark" style={{ width: '20px', height: '20px', marginRight: '8px' }} />
                <Text variant="mediumPlus">Interactive Course Materials</Text>
              </div>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <img src={checkmarkIcon} alt="Checkmark" style={{ width: '20px', height: '20px', marginRight: '8px' }} />
                <Text variant="mediumPlus">Expert Instructor Support</Text>
              </div>
            </Stack>
            <PrimaryButton text="Discover More" href="/sitepages/OnlineCourses.aspx" style={{ backgroundColor: '#0078d4', color: '#fff' }} />
          </div>
          <Stack horizontalAlign="center" style={{ flex: '1' }}>
            <img src={courseImage} alt="Courses" style={{ width: '250px', borderRadius: '50%' }} />
          </Stack>
        </div>
      </section>

    </div>
  );
};

export default HomePage;
